"""Event management platform package."""

